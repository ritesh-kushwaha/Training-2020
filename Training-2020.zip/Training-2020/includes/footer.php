<footer class="footer" style="position:fixed;">
  <div class="container">
      <p> &copy  Copyright 2020  Lifestyle Store. Ritesh Kushwaha</p>
  </div>
</footer>
